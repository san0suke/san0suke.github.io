// Month-level résumé dates. UTC day arithmetic avoids DST shifts.
const DAY = 86400000;
export const jobs = [
  ['2010-10-01','2012-12-31'], ['2012-12-01','2013-06-30'],
  ['2013-07-01','2014-03-31'], ['2014-03-01','2014-06-30'],
  ['2014-08-01','2015-04-30'], ['2015-05-01','2018-07-31'],
  ['2018-07-01','2024-08-31'], ['2024-08-01','2024-11-30'],
  ['2024-12-01',null]
];
export function dayNumber(iso) { return Math.floor(Date.parse(iso+'T00:00:00Z') / DAY); }
export function saoPauloDate(date = new Date()) {
  const parts = new Intl.DateTimeFormat('en-CA',{timeZone:'America/Sao_Paulo',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(date);
  const get = type => parts.find(p=>p.type===type).value;
  return `${get('year')}-${get('month')}-${get('day')}`;
}
export function mergeIntervals(intervals) {
  const result=[];
  for(const [start,end] of intervals.slice().sort((a,b)=>a[0]-b[0])) {
    if(end<start) continue;
    const prev=result.at(-1);
    if(prev && start<=prev[1]+1) prev[1]=Math.max(prev[1],end);
    else result.push([start,end]);
  }
  return result;
}
export function businessDays(start,end) {
  if(end<start) return 0;
  const n=end-start+1, weeks=Math.floor(n/7);
  let count=weeks*5;
  for(let day=start+weeks*7;day<=end;day++) {const weekday=((day+4)%7+7)%7;if(weekday!==0 && weekday!==6)count++;}
  return count;
}
export function calculateExperience(asOf=saoPauloDate()) {
  const today=dayNumber(asOf);
  const ranges=mergeIntervals(jobs.map(([a,b])=>[dayNumber(a),Math.min(today,b?dayNumber(b):today)]));
  const days=ranges.reduce((sum,[a,b])=>sum+businessDays(a,b),0);
  const calendarDays=ranges.reduce((sum,[a,b])=>sum+b-a+1,0);
  const teachingStart=dayNumber('2015-01-01'),teachingEnd=Math.min(today,dayNumber('2018-04-30'));
  // Only add teaching hours that overlap employment. Forgenator is not an extra full-time job.
  const teachingDays=ranges.reduce((sum,[a,b])=>sum+businessDays(Math.max(a,teachingStart),Math.min(b,teachingEnd)),0);
  return {asOf,years:Math.floor(calendarDays/365.2425),days,hours:days*8+teachingDays*3,teachingDays,extraHours:teachingDays*3,calendarDays};
}
