// A complete local Blob makes every frame seekable on the very first visit.
function waitFor(video, event, ready, signal, timeout = 12000) {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) return reject(new DOMException('Aborted', 'AbortError'));
    if (ready()) return resolve();
    const finish = error => {
      clearTimeout(timer);
      video.removeEventListener(event, done);
      video.removeEventListener('error', failed);
      signal?.removeEventListener('abort', aborted);
      error ? reject(error) : resolve();
    };
    const done = () => finish();
    const failed = () => finish(new Error('Video decoding failed'));
    const aborted = () => finish(new DOMException('Aborted', 'AbortError'));
    const timer = setTimeout(() => finish(new Error('Video preparation timed out')), timeout);
    video.addEventListener(event, done, {once: true});
    video.addEventListener('error', failed, {once: true});
    signal?.addEventListener('abort', aborted, {once: true});
  });
}

export async function prepareScrollVideo(video, source, {signal, onProgress = () => {}} = {}) {
  const response = await fetch(source, {signal, cache: 'default'});
  if (!response.ok) throw new Error(`Video HTTP ${response.status}`);
  const length = Number(response.headers.get('Content-Length'));
  let blob;
  if (response.body?.getReader) {
    const reader = response.body.getReader(), chunks = [];
    let received = 0;
    while (true) {
      const {done, value} = await reader.read();
      if (done) break;
      chunks.push(value); received += value.byteLength;
      onProgress(length ? Math.min(.86, received / length * .86) : Math.min(.8, received / (received + 2000000)));
    }
    blob = new Blob(chunks, {type: 'video/mp4'});
  } else blob = await response.blob();
  if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');
  if (!blob.size) throw new Error('Empty video');
  const objectURL = URL.createObjectURL(blob);
  let controller;
  try {
    video.muted = true; video.defaultMuted = true; video.playsInline = true;
    video.src = objectURL;
    const metadata = waitFor(video, 'loadedmetadata', () => false, signal);
    video.load();
    await metadata;
    await waitFor(video, 'loadeddata', () => video.readyState >= 2, signal);
    if (!Number.isFinite(video.duration) || video.duration <= 0) throw new Error('Invalid video duration');
    onProgress(.91);
    // Warm the decoder. Muted playback is normally allowed; seeking also works
    // when a browser requires a gesture, so that rejection is not a load error.
    let playTimer;
    try {
      await Promise.race([video.play(), new Promise(resolve => {playTimer = setTimeout(resolve, 1500);})]);
    } catch {} finally {clearTimeout(playTimer); video.pause();}
    if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');
    const verifySeek = async target => {
      if (Math.abs(video.currentTime - target) < .015 && !video.seeking) return;
      const completed = waitFor(video, 'seeked', () => false, signal);
      video.currentTime = target;
      await completed;
    };
    // Exercise the same API that scroll will use before dismissing the loader.
    await verifySeek(Math.min(.125, video.duration / 2));
    onProgress(.96);
    await verifySeek(0);
    controller = createVideoScrubber(video);
    onProgress(1);
    return {...controller, destroy() {controller.destroy(); video.pause(); video.removeAttribute('src'); video.load(); URL.revokeObjectURL(objectURL);}};
  } catch (error) {
    controller?.destroy(); video.pause(); video.removeAttribute('src'); video.load(); URL.revokeObjectURL(objectURL);
    throw error;
  }
}

export function createVideoScrubber(video, clock = globalThis) {
  let desired = 0, frame = 0, watchdog = 0, destroyed = false;
  const cancelWatchdog = () => {clock.clearTimeout(watchdog); watchdog = 0;};
  const request = () => {
    if (!frame && !destroyed) frame = clock.requestAnimationFrame(flush);
  };
  function flush() {
    frame = 0;
    if (destroyed || video.readyState < 2 || video.seeking) return;
    if (Math.abs(video.currentTime - desired) < 1 / 48) return;
    try {
      video.currentTime = desired;
      cancelWatchdog();
      watchdog = clock.setTimeout(() => {
        // Reissue the latest target if a browser discarded a seek event.
        if (!destroyed) {try {video.currentTime = desired;} catch {} request();}
      }, 1600);
    } catch {request();}
  }
  const settled = () => {cancelWatchdog(); request();};
  video.addEventListener('seeked', settled);
  video.addEventListener('canplay', settled);
  return {
    seek(progress) {
      if (!Number.isFinite(progress) || !Number.isFinite(video.duration)) return;
      desired = Math.max(0, Math.min(1, progress)) * Math.max(0, video.duration - 1 / 24);
      request();
    },
    refresh: request,
    destroy() {
      destroyed = true; clock.cancelAnimationFrame(frame); cancelWatchdog();
      video.removeEventListener('seeked', settled); video.removeEventListener('canplay', settled);
    }
  };
}
