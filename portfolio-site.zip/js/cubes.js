import * as THREE from 'three';
import {RoundedBoxGeometry} from '../vendor/RoundedBoxGeometry.js';
import {RoomEnvironment} from '../vendor/RoomEnvironment.js';
import {createCarouselMotion} from './carousel-motion.js?v=20261014-12';

export async function createCarousel(host,items,callbacks={}) {
  const renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,powerPreference:'low-power'});
  renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.7));
  renderer.outputColorSpace=THREE.SRGBColorSpace;
  renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.08;
  host.append(renderer.domElement);renderer.domElement.setAttribute('aria-hidden','true');
  const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(28,1,.1,60);
  camera.position.set(0,1.55,9.3);camera.lookAt(0,-.1,0);
  const environment=new RoomEnvironment();const pmrem=new THREE.PMREMGenerator(renderer);
  const envTarget=pmrem.fromScene(environment,.04);scene.environment=envTarget.texture;environment.dispose();pmrem.dispose();
  const key=new THREE.DirectionalLight(0xffdfb0,3.2);key.position.set(-4,6,5);scene.add(key);
  const rim=new THREE.DirectionalLight(0x9ad8c5,2.4);rim.position.set(5,2,-1);scene.add(rim);
  scene.add(new THREE.AmbientLight(0xd5e2dc,.4));
  const geometry=new RoundedBoxGeometry(1.72,1.72,1.72,4,.13);
  const plane=new THREE.PlaneGeometry(1.4,1.4);
  const cubes=[],pickables=[],resources=[];
  let reduced=callbacks.reduced||false,active=false,raf=0,failed=false,hovered=null;
  let pointerX=0,pointerY=0,drag=null,lastTime=0,lastPreview=null,renderWidth=0,renderHeight=0;
  const motion=createCarouselMotion(items.length);

  // Actual surface height maps: different grain for ceramic, brushed metal and circuitry.
  function bumpTexture(kind,seed){const canvas=document.createElement('canvas');canvas.width=canvas.height=256;const c=canvas.getContext('2d');
    let state=seed+17;const rand=()=>{state=(state*1664525+1013904223)>>>0;return state/4294967296;};
    c.fillStyle='#888';c.fillRect(0,0,256,256);
    if(kind==='circuit'){c.strokeStyle='#bebebe';c.lineWidth=2;for(let i=0;i<15;i++){const x=Math.floor(rand()*15)*16,y=Math.floor(rand()*15)*16;c.beginPath();c.moveTo(x,y);c.lineTo(x+32,y);c.lineTo(x+32,y+48);c.lineTo(x+64,y+48);c.stroke();c.fillStyle='#ddd';c.fillRect(x-2,y-2,4,4);}}
    else if(kind==='brushed'){for(let y=0;y<256;y++){const v=100+Math.floor(rand()*65);c.strokeStyle=`rgb(${v},${v},${v})`;c.beginPath();c.moveTo(0,y);c.lineTo(256,y+.7);c.stroke();}}
    else{const img=c.getImageData(0,0,256,256);for(let i=0;i<img.data.length;i+=4){const v=120+rand()*(kind==='grain'?35:12);img.data[i]=img.data[i+1]=img.data[i+2]=v;img.data[i+3]=255;}c.putImageData(img,0,0);if(kind==='crystal'){c.strokeStyle='#a8a8a8';c.lineWidth=.7;for(let i=0;i<10;i++){c.beginPath();c.moveTo(rand()*256,0);c.lineTo(rand()*256,256);c.stroke();}}}
    const tex=new THREE.CanvasTexture(canvas);tex.wrapS=tex.wrapT=THREE.RepeatWrapping;tex.anisotropy=Math.min(4,renderer.capabilities.getMaxAnisotropy());resources.push(tex);return tex;
  }
  async function faceTexture(item){const canvas=document.createElement('canvas');canvas.width=canvas.height=512;const c=canvas.getContext('2d');const img=new Image();
    await new Promise(resolve=>{img.onload=resolve;img.onerror=resolve;img.src=`./assets/icons/${item.id}.svg`;});
    // Fit the name first, then center the logo and label as one compact group.
    c.textAlign='center';c.textBaseline='alphabetic';
    const maxWidth=424;let fontSize=82,lines=[item.name];
    const setFont=()=>{c.font=`700 ${fontSize}px DM, Arial, sans-serif`;};setFont();
    const words=item.name.split(/\s+/);
    if(c.measureText(item.name).width>maxWidth&&words.length>1){
      let best=Infinity;
      for(let split=1;split<words.length;split++){
        const candidate=[words.slice(0,split).join(' '),words.slice(split).join(' ')];
        const width=Math.max(...candidate.map(line=>c.measureText(line).width));
        if(width<best){best=width;lines=candidate;}
      }
      fontSize=76;setFont();
    }
    while(Math.max(...lines.map(line=>c.measureText(line).width))>maxWidth&&fontSize>24){fontSize-=2;setFont();}
    const metrics=lines.map(line=>c.measureText(line));
    const ascent=metrics[0].actualBoundingBoxAscent??fontSize*.78;
    const descent=metrics.at(-1).actualBoundingBoxDescent??fontSize*.2;
    const lineHeight=fontSize*1.06;
    const textHeight=ascent+descent+(lines.length-1)*lineHeight;
    const ratio=img.naturalWidth?Math.min(236/img.naturalWidth,210/img.naturalHeight):0;
    const logoWidth=img.naturalWidth*ratio,logoHeight=img.naturalHeight*ratio;
    const gap=logoHeight?18:0,top=(512-logoHeight-gap-textHeight)/2;
    if(logoHeight){
      c.drawImage(img,(512-logoWidth)/2,top,logoWidth,logoHeight);
      c.globalCompositeOperation='source-in';c.fillStyle='#fff2d9';c.fillRect(0,0,512,512);c.globalCompositeOperation='source-over';
    }
    c.fillStyle='#fff4df';
    lines.forEach((line,index)=>c.fillText(line,256,top+logoHeight+gap+ascent+index*lineHeight));
    const tex=new THREE.CanvasTexture(canvas);tex.colorSpace=THREE.SRGBColorSpace;tex.anisotropy=Math.min(4,renderer.capabilities.getMaxAnisotropy());resources.push(tex);return tex;
  }
  await document.fonts.load('700 82px DM').catch(()=>{});
  const faces=await Promise.all(items.map(faceTexture));
  items.forEach((item,index)=>{
    const group=new THREE.Group();const mat=new THREE.MeshPhysicalMaterial({color:item.color,metalness:item.metalness,roughness:item.roughness,clearcoat:item.texture==='crystal'?1:.65,clearcoatRoughness:.15,envMapIntensity:1.6,bumpMap:bumpTexture(item.texture,index),bumpScale:item.texture==='circuit'?.035:.018});
    resources.push(mat);const body=new THREE.Mesh(geometry,mat);body.userData.index=index;group.add(body);pickables.push(body);
    const faceMat=new THREE.MeshBasicMaterial({map:faces[index],transparent:true,depthWrite:false,toneMapped:false});resources.push(faceMat);
    const front=new THREE.Mesh(plane,faceMat);front.position.z=.867;group.add(front);
    const side=new THREE.Mesh(plane,faceMat);side.position.x=-.867;side.rotation.y=-Math.PI/2;side.scale.setScalar(.85);group.add(side);
    const haloMat=new THREE.MeshBasicMaterial({color:item.color,transparent:true,opacity:0,side:THREE.BackSide,depthWrite:false});resources.push(haloMat);const halo=new THREE.Mesh(geometry,haloMat);halo.scale.setScalar(1.018);group.add(halo);
    const ringMat=new THREE.MeshBasicMaterial({color:item.color,transparent:true,opacity:.3,depthWrite:false});resources.push(ringMat);const ring=new THREE.Mesh(new THREE.TorusGeometry(1,.012,6,64),ringMat);ring.rotation.x=-Math.PI/2;ring.position.y=-1.3;scene.add(ring);
    scene.add(group);cubes.push({group,body,halo,ring});
  });
  // A restrained floor orbit and small particles provide real depth around the carousel.
  const orbit=new THREE.Mesh(new THREE.TorusGeometry(4.4,.009,6,140),new THREE.MeshBasicMaterial({color:0xc5a36f,transparent:true,opacity:.18}));orbit.rotation.x=-Math.PI/2;orbit.position.set(0,-1.3,-1.8);scene.add(orbit);
  const particlesGeo=new THREE.BufferGeometry();const vertices=[];for(let i=0;i<180;i++){const a=i*2.399963;vertices.push(Math.sin(a)*(4+(i%7)),((i*37)%100)/24-1.8,-2-(i%23)/3);}particlesGeo.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));const particles=new THREE.Points(particlesGeo,new THREE.PointsMaterial({color:0xb2c3ae,size:.021,transparent:true,opacity:.36,depthWrite:false}));scene.add(particles);
  const raycaster=new THREE.Raycaster(),point=new THREE.Vector2();
  function select(index,notify=false){cancelDrag(undefined,false);const selected=motion.select(index);hovered=null;if(notify)callbacks.onSelect?.(selected);requestRender();}
  function hit(e){const r=host.getBoundingClientRect();point.set((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1);raycaster.setFromCamera(point,camera);return raycaster.intersectObjects(pickables.filter(mesh=>mesh.parent.visible),false)[0]?.object.userData.index??null;}
  function preview(index){if(lastPreview!==index){lastPreview=index;callbacks.onPreview?.(index);}hovered=index;requestRender();}
  host.addEventListener('pointerdown',e=>{
    if(e.button!==0||e.isPrimary===false||drag)return;
    drag={x:e.clientX,y:e.clientY,id:e.pointerId,axis:null,step:Math.max(100,host.clientWidth/4)};
    motion.beginDrag();host.setPointerCapture(e.pointerId);requestRender();
  });
  host.addEventListener('pointermove',e=>{
    if(drag&&e.pointerId!==drag.id)return;
    if(e.pointerType==='mouse'){
      const r=host.getBoundingClientRect();pointerX=(e.clientX-r.left)/r.width*2-1;pointerY=(e.clientY-r.top)/r.height*2-1;
    }
    if(drag){
      const dx=e.clientX-drag.x,dy=e.clientY-drag.y;
      if(!drag.axis&&Math.max(Math.abs(dx),Math.abs(dy))>12){
        drag.axis=Math.abs(dx)>Math.abs(dy)*1.15?'x':'y';
        if(drag.axis==='x')preview(null);
      }
      if(drag.axis==='x'){motion.dragBy(dx/drag.step);requestRender();}
    }else if(e.pointerType==='mouse')preview(hit(e));
  });
  host.addEventListener('pointerup',e=>{
    if(!drag||e.pointerId!==drag.id)return;
    const {x,y,id,axis}=drag,dx=e.clientX-x,dy=e.clientY-y;drag=null;
    const selected=motion.endDrag(axis==='x'&&Math.abs(dx)>28?(dx<0?1:-1):0);
    if(host.hasPointerCapture(id))host.releasePointerCapture(id);
    if(axis==='x')callbacks.onSelect?.(selected);
    else if(Math.abs(dx)<10&&Math.abs(dy)<10){const index=hit(e);if(index!==null)select(index,true);}
    requestRender();
  });
  function cancelDrag(e,notify=true){
    if(!drag||(e&&e.pointerId!==drag.id))return;
    const {id,axis}=drag;drag=null;
    const selected=motion.endDrag();
    if(host.hasPointerCapture(id))host.releasePointerCapture(id);
    if(axis==='x'&&notify)callbacks.onSelect?.(selected);
    requestRender();
  }
  host.addEventListener('pointercancel',cancelDrag);host.addEventListener('pointerleave',()=>{pointerX=pointerY=0;if(!drag)preview(null);});
  host.addEventListener('lostpointercapture',cancelDrag);
  renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();failed=true;cancelAnimationFrame(raf);raf=0;callbacks.onFailure?.();});
  function resize(){
    const w=host.clientWidth,h=host.clientHeight;if(!w||!h||(w===renderWidth&&h===renderHeight)||failed)return;
    renderWidth=w;renderHeight=h;renderer.setSize(w,h,false);
    camera.aspect=w/h;camera.zoom=h<300?1.16:1;camera.updateProjectionMatrix();
    // Resizing clears the WebGL drawing buffer. Repaint in this same frame.
    if(active&&!document.hidden)draw(performance.now());
    requestRender();
  }
  function requestRender(){if(!raf&&!failed&&active&&!document.hidden)raf=requestAnimationFrame(render);}
  function render(time){raf=0;if(failed||!active||document.hidden)return;const dt=Math.min(.04,(time-lastTime)/1000||.016);lastTime=time;
    motion.advance(dt,reduced);draw(time);
    if(!reduced||Math.abs(motion.target-motion.position)>.001||drag)requestRender();
  }
  function draw(time){
    const t=reduced?0:time*.001;const maxVisible=host.clientWidth<650?1.65:2.75;
    cubes.forEach((cube,index)=>{const rel=motion.wrap(index-motion.position);const center=Math.max(0,1-Math.abs(rel));const focused=hovered===index?1:center;cube.group.visible=Math.abs(rel)<maxVisible;cube.ring.visible=cube.group.visible;if(!cube.group.visible)return;
      cube.group.position.set(rel*2.7,.1+focused*.17+(reduced?0:Math.sin(t*.65+index)*.045),-Math.abs(rel)*.7);
      cube.group.rotation.set(.09+(reduced?0:pointerY*.025),-.22+rel*.09+(reduced?0:Math.sin(t*.23+index)*.055),Math.sin(index*1.7)*.025);
      cube.group.scale.setScalar(.9+center*.3);cube.halo.material.opacity=focused*.2;
      cube.ring.position.x=cube.group.position.x;cube.ring.position.z=cube.group.position.z;cube.ring.scale.setScalar(.9+center*.35);cube.ring.material.opacity=.13+focused*.4;
    });
    camera.position.x=reduced?0:pointerX*.1;camera.lookAt(0,-.1,0);particles.rotation.y=reduced?0:Math.sin(t*.08)*.025;
    renderer.render(scene,camera);
  }
  const resizeObserver=new ResizeObserver(resize);resizeObserver.observe(host);
  const visibilityObserver=new IntersectionObserver(entries=>{active=entries[0].isIntersecting;if(active){lastTime=performance.now();requestRender();}else{cancelAnimationFrame(raf);raf=0;}},{rootMargin:'120px'});visibilityObserver.observe(host);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden){lastTime=performance.now();requestRender();}else{cancelAnimationFrame(raf);raf=0;}});
  resize();
  return {select,setReducedMotion(value){reduced=value;requestRender();},dispose(){failed=true;cancelAnimationFrame(raf);resizeObserver.disconnect();visibilityObserver.disconnect();geometry.dispose();plane.dispose();resources.forEach(r=>r.dispose());envTarget.dispose();renderer.dispose();renderer.domElement.remove();}};
}
