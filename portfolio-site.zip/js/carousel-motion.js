// Keep one continuous position for dragging and the settling animation.
export function createCarouselMotion(count) {
  const normalize = value => ((value % count) + count) % count;
  const wrap = value => normalize(value + count / 2) - count / 2;
  let position = 0, target = 0, selected = 0, anchor = null, moved = false;

  return {
    get position() { return position; },
    get target() { return target; },
    get selected() { return selected; },
    wrap,
    select(index) {
      selected = normalize(index);
      target += wrap(selected - normalize(target));
      anchor = null;
      return selected;
    },
    beginDrag() {
      anchor = position;
      moved = false;
    },
    dragBy(offset) {
      if (anchor === null) return;
      position = anchor - offset;
      moved = true;
    },
    endDrag(direction = 0) {
      if (anchor === null) return selected;
      if (moved) {
        const origin = Math.round(anchor);
        target = Math.round(position);
        // A short, deliberate swipe still advances one cube. Longer swipes
        // settle at the cube under the finger, instead of jumping backwards.
        if (direction && target === origin) target = origin + direction;
        selected = normalize(target);
      }
      anchor = null;
      // Do not reset position here: the next frame continues from the drag.
      return selected;
    },
    advance(dt, reduced = false) {
      if (anchor !== null) return position;
      position = reduced ? target : position + (target - position) * (1 - Math.exp(-dt * 8));
      if (Math.abs(target - position) < .0001) position = target;
      return position;
    }
  };
}
