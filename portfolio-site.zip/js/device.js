export function isMobileDevice(device) {
  // Touch laptops expose orientation APIs too. They must keep the desktop UI.
  return device.userAgentData?.mobile === true
    || /Android|iPhone|iPad|iPod|Mobile|Tablet/i.test(device.userAgent || '')
    || (/MacIntel/i.test(device.platform || '') && device.maxTouchPoints > 1);
}
