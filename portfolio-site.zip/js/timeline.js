export function timelineProgress(top, height, scroll, viewport) {
  return Math.max(0, Math.min(1, (scroll + viewport / 2 - top) / Math.max(1, height)));
}

export function installCareerTimeline() {
  const timeline = document.querySelector('#career-timeline');
  if (!timeline) return;
  const rows = [...timeline.querySelectorAll('.journey-item')];
  const dots = rows.map(row => row.querySelector('.journey-dot'));
  let frame = 0;
  function draw() {
    frame = 0;
    const rect = timeline.getBoundingClientRect();
    const progress = timelineProgress(rect.top + scrollY, rect.height, scrollY, innerHeight);
    timeline.style.setProperty('--journey-progress', progress);
    let active = -1;
    // Read all geometry before changing classes to avoid repeated layout work.
    const positions = rows.map((row, i) => ({row: row.getBoundingClientRect(), dot: dots[i].getBoundingClientRect()}));
    positions.forEach(({row, dot}, i) => {
      if (row.top < innerHeight * .85) rows[i].classList.add('is-visible');
      const reached = dot.top + dot.height / 2 <= innerHeight / 2 + 1;
      rows[i].classList.toggle('is-reached', reached);
      if (reached) active = i;
    });
    rows.forEach((row, i) => row.classList.toggle('is-active', i === active));
  }
  function refresh() { if (!frame) frame = requestAnimationFrame(draw); }
  timeline.classList.add('timeline-enhanced');
  addEventListener('scroll', refresh, {passive: true});
  addEventListener('resize', refresh);
  addEventListener('pageshow', refresh);
  new ResizeObserver(refresh).observe(timeline);
  document.fonts.ready.then(refresh);
  refresh();
}
