// Follow the actual browser viewport, including mobile browser bars and rotation.
export function nearestChapterIndex(sections, position) {
  if (!sections.length) return 0;
  return sections.reduce((best, section, index) => Math.abs(section.top - position) < Math.abs(sections[best].top - position) ? index : best, 0);
}

export function installResponsiveLayout() {
  const root = document.documentElement;
  const sections = [...document.querySelectorAll('main > .section')];
  let frame = 0;
  function viewport() {
    // Do not shrink chapters during pinch zoom: keep zoom and panning accessible.
    root.style.setProperty('--viewport-height', `${window.innerHeight}px`);
  }
  function fit() {
    frame = 0;
    const detail = document.querySelector('#tech-detail');
    document.querySelector('#carousel-shell').style.setProperty('--tech-detail-height', `${detail.offsetHeight}px`);
    // Remove a previous fallback before measuring the new viewport/content.
    sections.forEach(section => section.classList.remove('needs-room'));
    const overflow = sections.filter(section => !section.hasAttribute('data-free-scroll') && section.scrollHeight > section.clientHeight + 3);
    overflow.forEach(section => section.classList.add('needs-room'));
    document.dispatchEvent(new Event('chapterlayoutchange'));
  }
  function refresh() { if (!frame) frame = requestAnimationFrame(fit); }
  viewport();
  addEventListener('resize', () => { viewport(); refresh(); });
  addEventListener('pageshow', () => { viewport(); refresh(); });
  document.fonts.ready.then(refresh);
  document.fonts.addEventListener?.('loadingdone', refresh);
  refresh();
  return {refresh};
}

export function installInfoDialogs() {
  document.querySelectorAll('[data-open-dialog]').forEach(button => {
    const dialog = document.getElementById(button.dataset.openDialog);
    button.addEventListener('click', () => {
      dialog.showModal();
      document.body.classList.add('modal-open');
    });
    dialog.querySelector('[data-close-dialog]').addEventListener('click', () => dialog.close());
    dialog.addEventListener('click', event => {
      const rect = dialog.getBoundingClientRect();
      if (event.target === dialog && (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom)) dialog.close();
    });
    dialog.addEventListener('close', () => {
      document.body.classList.remove('modal-open');
      button.focus({preventScroll: true});
    });
  });
}
